#!/bin/bash
cd /03-student/Lucky_Duck_Investigations/Roulette_Loss_Investigation/Player_Analysis
grep -i $1_win_loss_player_data:"$2" Roulette_Losses
cd /03-student/Lucky_Duck_Investigations/Roulette_Loss_Investigation/Dealer_Analysis
awk -F" " '{print $1, $2, $5, $6}' $1_Dealer_schedule | grep -i "$3"

